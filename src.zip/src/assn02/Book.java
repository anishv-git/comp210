package assn02;

public class Book {
    private String title;
    private String author;
    private boolean isCheckedOut;

    public Book(String title, String author) {
        this.title = title;
        this.author = author;
        this.isCheckedOut = false;
    }

    public void checkOut() {
        this.isCheckedOut = true;
    }

    public void returnBook() {
        this.isCheckedOut = false;
    }

    public String getDetails() {
        String status = isCheckedOut ? "Yes" : "No";
        return "Title: " + this.title + ", Author: " + this.author + ", Checked Out: " + status;
    }
}