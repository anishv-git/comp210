package assn02;

import java.util.Scanner;

public class LMS {

    private static Book[] library = new Book[5];
    private static int bookCount = 0;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            displayMenu();
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 0:
                    System.out.println("Bye for now!");
                    return;
                case 1:
                    addBook(scanner);
                    break;
                case 2:
                    displayBooks();
                    break;
                case 3:
                    checkOutBook(scanner);
                    break;
                case 4:
                    returnBook(scanner);
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
                    break;
            }
        }
    }

    public static void displayMenu() {
        System.out.println("Library Menu:");
        System.out.println("0. Exit");
        System.out.println("1. Add a Book");
        System.out.println("2. Display All Books");
        System.out.println("3. Check Out a Book");
        System.out.println("4. Return a Book");
        System.out.println("Enter your choice:");
    }

    public static void addBook(Scanner scanner) {
        if (bookCount >= 5) {
            System.out.println("Book not added. Library is full!");
            return;
        }

        System.out.println("Enter book title:");
        String title = scanner.nextLine();
        System.out.println("Enter book author:");
        String author = scanner.nextLine();

        library[bookCount] = new Book(title, author);
        bookCount++;
        System.out.println("Book added to library!");
    }

    public static void displayBooks() {
        System.out.println("Books in Library:");
        for (int i = 0; i < bookCount; i++) {
            System.out.println((i + 1) + ". " + library[i].getDetails());
        }
    }

    public static void checkOutBook(Scanner scanner) {
        System.out.println("Enter book number to check out:");
        int bookNum = scanner.nextInt();
        scanner.nextLine();

        if (bookNum > 0 && bookNum <= bookCount) {
            library[bookNum - 1].checkOut();
            System.out.println("Book checked out!");
        } else {
            System.out.println("Invalid book number!");
        }
    }

    public static void returnBook(Scanner scanner) {
        System.out.println("Enter book number to return:");
        int bookNum = scanner.nextInt();
        scanner.nextLine();

        if (bookNum > 0 && bookNum <= bookCount) {
            library[bookNum - 1].returnBook();
            System.out.println("Book returned!");
        } else {
            System.out.println("Invalid book number!");
        }
    }
}